#ifndef CODE_H
#define CODE_H

extern void initcode();
extern void execute();

extern void eval();
extern void add();
extern void sub();
extern void mul();
extern void divide();
extern void neg();
extern void power();
extern void assign();
extern void builtin();
extern void varpush();
extern void constpush();
extern void print();
extern void gt();
extern void lt();
extern void gte();
extern void lte();

extern instruction *code();

#endif
