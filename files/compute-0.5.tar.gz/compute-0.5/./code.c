#include <stdio.h>
#include "symbol.h"
#include "y.tab.h"
#include "builtin.h"
#include "parser.h"
#include "code.h"

#define NSTACK 256

static datum stack[NSTACK]; /* the stack */
static datum *sp; /* stack pointer; the free spot */

#define NPROG 2000

instruction prog[NPROG]; /* the machine */
instruction *pp; /* program pointer; the free spot on code generation */
instruction *pc; /* program counter */

void initcode()
{
  sp = stack;
  pp = prog;
}

void push(datum d)
{
  if (sp >= &stack[NSTACK])
    execerr("stack overflow", NULL);
  *sp++ = d;
}

datum pop()
{
  datum tmp;
  if (sp <= stack)
    execerr("stack underflow", NULL);

  tmp = *--sp;
  return tmp;
}

instruction *code(instruction f)
{
  instruction *oldp; oldp = pp;
  if (pp >= &prog[NPROG])
    execerr("program too big", NULL);
  *pp++ = f; return oldp;
}

void execute(instruction *p)
{
  for (pc = p; *pc != STOP; )
    (* (*pc++))();
}

void constpush()
{
  datum d;
  d.val = ( (symbol *) *pc++)->u.val;
  push(d);
}

void varpush()
{
  datum d;
  d.sym = (symbol *) (*pc++);
  push(d);
}

void add()
{
  datum d1; datum d2;
  d2 = pop();
  d1 = pop();
  d1.val += d2.val;
  push(d1);
}

void eval()
{
  datum d;
  d = pop();
  if (d.sym->type == UNDEF)
    execerr("undefined variable", d.sym->name);
  d.val = d.sym->u.val;
  push(d);
}

void assign()
{
  datum d1; datum d2;
  d1 = pop();
  d2 = pop();
  if (d1.sym->type != VAR && d1.sym->type != UNDEF)
    execerr("assignment to non-variable", d1.sym->name);
  d1.sym->u.val = d2.val;
  d1.sym->type = VAR;
  push(d2);
}

void print()
{
  datum d;
  d = pop();
  printf("  %.8g\n", d.val);
}

void rand()
{
  datum d;
  d.val = (* (double (*)())(*pc++))(d.val);
  push(d);
}

void builtin()
{
  datum d;

  d = pop();
  d.val = (* (double (*)())(*pc++))(d.val);
  push(d);
}

void divide()
{
  datum d1; datum d2;
  d2 = pop();
  if (d2.val == 0.0)
    execerr("division by zero", NULL);
  d1 = pop();
  d1.val /= d2.val;
  push(d1);
}

void neg()
{
  datum d;
  d = pop();
  d.val = -d.val;
  push(d);
}

void gt()
{
  datum d1; datum d2;
  d2 = pop();
  d1 = pop();
  d1.val = (double)(d1.val > d2.val);
  push(d1);
}

void gte()
{
  datum d1; datum d2;
  d2 = pop();
  d1 = pop();
  d1.val = (double)(d1.val >= d2.val);
  push(d1);
}

void lt()
{
  datum d1; datum d2;
  d2 = pop();
  d1 = pop();
  d1.val = (double)(d1.val < d2.val);
  push(d1);
}

void lte()
{
  datum d1; datum d2;
  d2 = pop();
  d1 = pop();
  d1.val = (double)(d1.val <= d2.val);
  push(d1);
}

void power()
{
  datum d1; datum d2;
  d2 = pop(); d1 = pop();

  d1.val = do_pow(d1.val, d2.val);
  push(d1);
}

void sub()
{
  datum d1; datum d2;
  d2 = pop();
  d1 = pop();
  d1.val -= d2.val;
  push(d1);
}

void mul()
{
  datum d1; datum d2;
  d2 = pop();
  d1 = pop();
  d1.val *= d2.val;
  push(d1);
}
