#ifndef SYMBOL_H
#define SYMBOL_H

#define SYMSIZE 15

typedef struct symbol {
  char *name; /* the name of the symbol */
  short type; /* types are VAR, BLTIN, UNDEF */

  union {
    double val; /* used if symbol is a variable/constant */
    double (*ptr)(); /* used if symbol is a built in variable/function */
  } u;

  struct symbol *next; /* this is a linked list of symbols */
} symbol;

symbol *install();
symbol *lookup();

typedef union datum { /* interpreter stack type */

  /* the stack is filled with these things; they are either values, such
   * as numbers, or they are variables or built in functions. stuff like
   * that. */

  double val;
  symbol *sym;

} datum;

extern datum pop();


/* each machine instruction is a function that returns an integer; here
 * we typedef it so that the syntax becomes a little more usual. the
 * STOP constant is used to tell the machine that execution should
 * cease; it takes the value zero, by definition. */

typedef int (*instruction)();
#define STOP (instruction) 0

/* this array, allocated somewhere else, is actually the memory of the
 * machine; every instruction goes in here. */
extern instruction prog[];

#endif
