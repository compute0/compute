#include <string.h>
#include <math.h>
#include "symbol.h"
#include "y.tab.h"
#include "builtin.h"

static struct {
  
  /* a constant has a name, and a value; we initialize them here. */

  char *name;
  double cval;

} cons[] = {
  { "pi", 3.14159265358979323846 },
  { "e", 2.71828182845904523536 },
  { "deg", 57.29577951308232087680 },
  { "p", 0.0 },
  { 0, 0 }

};

static struct {

  /* we'll loop through this structure; each built in symbol has a
   * function asssociated with it; each of them must always return a
   * double; it makes sense because so far that's the only way to get a
   * feedback from the function; if you don't need any feedback, you
   * don't need a function call. */

  char *name;
  double (*func)();

} builtins[] = {
  { "sin", sin },
  { "cos", cos },
  { "abs", fabs },
  { "atan", atan },
  { "log", do_log },
  { "log10", do_log10 },
  { "exp", do_exp },
  { "sqrt", do_sqrt },
  { "int", do_int },
  { "rand", do_rand },
  { 0, 0 }
};

int isreadonly(char *s)
{
  /* a program cannot write over constants such as pi and e, of
   * course. but notice that p is a variable that stores the last final
   * value from the machine; p is, however, read-only, so we load it up
   * in the constants array so that we can check if the user is trying
   * to write over it, and we complain if so. */

  int i;
  for (i=0; cons[i].name; ++i) 
    if (! strncmp(s,cons[i].name,SYMSIZE) ) return 1;

  return 0;
}

void init(void)
{
  /* this function will install the built in symbols and the built in
   * constants; that's all it does. */

  int i; symbol *s;

  for (i=0; cons[i].name; ++i)
    install(cons[i].name, VAR, cons[i].cval);

  for (i=0; builtins[i].name; ++i) {
    s = install(builtins[i].name, BUILTIN, 0.0);
    s->u.ptr = builtins[i].func;
  }
}
