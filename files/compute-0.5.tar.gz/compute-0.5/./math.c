#include <math.h>
#include <errno.h>
#include <time.h>
#include "parser.h"
#include "builtin.h"

static unsigned long seed;
static unsigned int r(void)
{
  if (!seed) seed = time(0); 

  seed = seed * 1103515245 + 12345;
  return (unsigned int) (seed/65536) % 32768;
}

double errcheck(double d, char *s)
{
  if (errno == EDOM) {
    errno = 0;
    execerr(s, "argument out of domain");
  } else if (errno == ERANGE) {
    errno = 0;
    execerr(s, "result out of range");
  }

  return d;
}

double do_rand(double lim)
{
  int n; n = (long) lim; n = r() % n;
  return (double) n;
}

double do_log(double x)
{
  return errcheck(log(x),"log");
}

double do_log10(double x)
{
  return errcheck(log10(x),"log10");
}

double do_exp(double x)
{
  return errcheck(exp(x), "exp");
}

double do_sqrt(double x)
{
  return errcheck(sqrt(x), "sqrt");
}

double do_pow(double x, double y)
{
  return errcheck(pow(x,y), "exponentiation");
}

double do_int(double x)
{
  return (double)(long) x;
}
