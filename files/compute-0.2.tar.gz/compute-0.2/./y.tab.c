#ifndef lint
static char const 
yyrcsid[] = "$FreeBSD: src/usr.bin/yacc/skeleton.c,v 1.28.2.1 2001/07/19 05:46:39 peter Exp $";
#endif
#include <stdlib.h>
#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define YYLEX yylex()
#define YYEMPTY -1
#define yyclearin (yychar=(YYEMPTY))
#define yyerrok (yyerrflag=0)
#define YYRECOVERING() (yyerrflag!=0)
#if defined(__cplusplus) || __STDC__
static int yygrowstack(void);
#else
static int yygrowstack();
#endif
#define YYPREFIX "yy"
#line 2 "grammar.y"
#include "symbol.h"
extern double dpow();
#line 6 "grammar.y"
typedef union { double val; symbol *sym; } YYSTYPE;
#line 26 "y.tab.c"
#define YYERRCODE 256
#define NUMBER 257
#define VAR 258
#define BLTIN 259
#define UNDEF 260
#define UNARYPLUS 261
#define UNARYMINUS 262
const short yylhs[] = {                                        -1,
    0,    0,    0,    0,    0,    2,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
};
const short yylen[] = {                                         2,
    0,    2,    3,    3,    3,    3,    1,    1,    1,    4,
    3,    3,    3,    3,    3,    3,    3,    3,    2,    2,
};
const short yydefred[] = {                                      1,
    0,    0,    7,    0,    0,    0,    0,    2,    0,    0,
    0,    5,    0,    0,    0,    9,    0,    0,    0,    0,
    0,    0,    0,    0,    4,    3,    0,   11,    0,   18,
    0,    0,    0,    0,    0,    0,   10,
};
const short yydgoto[] = {                                       1,
   10,   16,
};
const short yysindex[] = {                                      0,
  -10,   -7,    0,  -43,  -17,  -35,  -35,    0,  -35,  -23,
  -32,    0,  -35,  -39,  -66,    0,  -66,   -3,  -35,  -35,
  -35,  -35,  -35,  -35,    0,    0,   11,    0,    4,    0,
  -21,  -21,  -28,  -28,  -66,  -66,    0,
};
const short yyrindex[] = {                                      0,
    0,    0,    0,  -30,    0,    0,    0,    0,    0,    0,
   18,    0,    0,    0,   33,    0,   40,    0,    0,    0,
    0,    0,    0,    0,    0,    0,  -16,    0,    0,    0,
  102,  107,   92,   99,   59,   66,    0,
};
const short yygindex[] = {                                      0,
  108,   30,
};
#define YYTABLESIZE 249
const short yytable[] = {                                       8,
    9,   28,   12,    6,    9,    7,    8,    6,   23,    7,
    8,    8,    8,   23,    8,   23,    8,   13,   21,   19,
   21,   20,   14,   22,    6,   22,   26,   24,    8,    9,
   11,    0,    6,   23,    7,   25,    0,   30,   21,   19,
   23,   20,    6,   22,   37,   21,   19,   23,   20,    0,
   22,    0,   21,   19,    9,   20,    0,   22,    0,    9,
    9,    0,    9,    8,    9,   24,    0,    0,    0,   19,
   24,    0,   24,   19,   19,   19,   20,   19,    0,   19,
   20,   20,   20,    0,   20,    0,   20,    0,    0,    0,
   24,   19,    0,    0,    0,   16,    0,   24,   20,   16,
   16,   16,   17,   16,   24,   16,   17,   17,   17,    0,
   17,    9,   17,   15,   17,    0,   18,   16,    0,    0,
   27,   29,    0,    0,   17,    0,   31,   32,   33,   34,
   35,   36,   14,   14,   14,    0,   14,    0,   14,   15,
   15,   15,   12,   15,   12,   15,   12,   13,    0,   13,
   14,   13,    0,    0,    0,    0,    0,   15,    0,    0,
   12,    0,    0,    0,    0,   13,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    3,    4,    5,
    0,    3,    4,    5,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    2,    3,    4,    5,
};
const short yycheck[] = {                                      10,
   40,   41,   10,   43,   40,   45,   37,   43,   37,   45,
   41,   42,   43,   37,   45,   37,   47,   61,   42,   43,
   42,   45,   40,   47,   41,   47,   59,   94,   59,   40,
    1,   -1,   43,   37,   45,   59,   -1,   41,   42,   43,
   37,   45,   59,   47,   41,   42,   43,   37,   45,   -1,
   47,   -1,   42,   43,   37,   45,   -1,   47,   -1,   42,
   43,   -1,   45,   94,   47,   94,   -1,   -1,   -1,   37,
   94,   -1,   94,   41,   42,   43,   37,   45,   -1,   47,
   41,   42,   43,   -1,   45,   -1,   47,   -1,   -1,   -1,
   94,   59,   -1,   -1,   -1,   37,   -1,   94,   59,   41,
   42,   43,   37,   45,   94,   47,   41,   42,   43,   -1,
   45,   94,   47,    6,    7,   -1,    9,   59,   -1,   -1,
   13,   14,   -1,   -1,   59,   -1,   19,   20,   21,   22,
   23,   24,   41,   42,   43,   -1,   45,   -1,   47,   41,
   42,   43,   41,   45,   43,   47,   45,   41,   -1,   43,
   59,   45,   -1,   -1,   -1,   -1,   -1,   59,   -1,   -1,
   59,   -1,   -1,   -1,   -1,   59,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,  257,  258,  259,
   -1,  257,  258,  259,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,  256,  257,  258,  259,
};
#define YYFINAL 1
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 262
#if YYDEBUG
const char * const yyname[] = {
"end-of-file",0,0,0,0,0,0,0,0,0,"'\\n'",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,"'%'",0,0,"'('","')'","'*'","'+'",0,"'-'",0,"'/'",0,0,0,0,0,0,0,0,0,
0,0,"';'",0,"'='",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,"'^'",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,"NUMBER","VAR","BLTIN","UNDEF","UNARYPLUS","UNARYMINUS",
};
const char * const yyrule[] = {
"$accept : list",
"list :",
"list : list '\\n'",
"list : list asgn ';'",
"list : list expr ';'",
"list : list error '\\n'",
"asgn : VAR '=' expr",
"expr : NUMBER",
"expr : VAR",
"expr : asgn",
"expr : BLTIN '(' expr ')'",
"expr : BLTIN '(' ')'",
"expr : expr '+' expr",
"expr : expr '-' expr",
"expr : expr '*' expr",
"expr : expr '/' expr",
"expr : expr '%' expr",
"expr : expr '^' expr",
"expr : '(' expr ')'",
"expr : '+' expr",
"expr : '-' expr",
};
#endif
#if YYDEBUG
#include <stdio.h>
#endif
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 10000
#define YYMAXDEPTH 10000
#endif
#endif
#define YYINITSTACKSIZE 200
int yydebug;
int yynerrs;
int yyerrflag;
int yychar;
short *yyssp;
YYSTYPE *yyvsp;
YYSTYPE yyval;
YYSTYPE yylval;
short *yyss;
short *yysslim;
YYSTYPE *yyvs;
int yystacksize;
#line 58 "grammar.y"

#include <stdio.h>
#include <ctype.h>
#include <signal.h>
#include <setjmp.h>

char *progname; int lineno = 1; jmp_buf begin;

int yylex(void); void warn(char *, char *); void yyerror(char *s); 
int yyparse(); void fpecatch(int); void execerr(char *, char *);
void init(void); int isreadonly(char*);

int main(int argc, char *argv[])
{
  progname = argv[0]; init();
  setjmp(begin); signal(SIGFPE, fpecatch);
  yyparse(); exit(0);
}

int yylex(void)
{
  int c;
  while ( (c = getchar()) == ' ' || c == '\t') ;

  if (c == EOF) return 0;

  if (c == '.' || isdigit(c)) { 
    ungetc(c, stdin); scanf("%lf", &yylval.val); return NUMBER;
  }

  if (c == '\n') ++lineno;

  if (isalpha(c)) {
    symbol *s; char sbf[100]; char *p; p = sbf;

    do { *p++ = c; } while( (c=getchar()) != EOF && isalnum(c));

    ungetc(c, stdin); *p = '\0';
    if ( (s=lookup(sbf)) == 0 ) s = install(sbf, UNDEF, 0.0);
    
    yylval.sym = s; return s->type == UNDEF ? VAR : s->type;
  }

  return c;
}

void warn(char *s, char *t)
{
  fprintf(stderr, "%s: %s", progname, s); if (t) fprintf(stderr, " %s", t);
  fprintf(stderr, " near line %d\n", lineno);
}

void yyerror(char *s)
{
  warn(s, (char *) 0);
}

void execerr(char *s, char *t)
{
  warn(s, t); longjmp(begin, 0);
}

void fpecatch(int e)
{
  execerr("floating point exception", (char *) 0);
}
#line 255 "y.tab.c"
/* allocate initial stack or double stack size, up to YYMAXDEPTH */
static int yygrowstack()
{
    int newsize, i;
    short *newss;
    YYSTYPE *newvs;

    if ((newsize = yystacksize) == 0)
        newsize = YYINITSTACKSIZE;
    else if (newsize >= YYMAXDEPTH)
        return -1;
    else if ((newsize *= 2) > YYMAXDEPTH)
        newsize = YYMAXDEPTH;
    i = yyssp - yyss;
    newss = yyss ? (short *)realloc(yyss, newsize * sizeof *newss) :
      (short *)malloc(newsize * sizeof *newss);
    if (newss == NULL)
        return -1;
    yyss = newss;
    yyssp = newss + i;
    newvs = yyvs ? (YYSTYPE *)realloc(yyvs, newsize * sizeof *newvs) :
      (YYSTYPE *)malloc(newsize * sizeof *newvs);
    if (newvs == NULL)
        return -1;
    yyvs = newvs;
    yyvsp = newvs + i;
    yystacksize = newsize;
    yysslim = yyss + newsize - 1;
    return 0;
}

#define YYABORT goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab

#ifndef YYPARSE_PARAM
#if defined(__cplusplus) || __STDC__
#define YYPARSE_PARAM_ARG void
#define YYPARSE_PARAM_DECL
#else	/* ! ANSI-C/C++ */
#define YYPARSE_PARAM_ARG
#define YYPARSE_PARAM_DECL
#endif	/* ANSI-C/C++ */
#else	/* YYPARSE_PARAM */
#ifndef YYPARSE_PARAM_TYPE
#define YYPARSE_PARAM_TYPE void *
#endif
#if defined(__cplusplus) || __STDC__
#define YYPARSE_PARAM_ARG YYPARSE_PARAM_TYPE YYPARSE_PARAM
#define YYPARSE_PARAM_DECL
#else	/* ! ANSI-C/C++ */
#define YYPARSE_PARAM_ARG YYPARSE_PARAM
#define YYPARSE_PARAM_DECL YYPARSE_PARAM_TYPE YYPARSE_PARAM;
#endif	/* ANSI-C/C++ */
#endif	/* ! YYPARSE_PARAM */

int
yyparse (YYPARSE_PARAM_ARG)
    YYPARSE_PARAM_DECL
{
    register int yym, yyn, yystate;
#if YYDEBUG
    register const char *yys;

    if ((yys = getenv("YYDEBUG")))
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = (-1);

    if (yyss == NULL && yygrowstack()) goto yyoverflow;
    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if ((yyn = yydefred[yystate])) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yyssp >= yysslim && yygrowstack())
        {
            goto yyoverflow;
        }
        *++yyssp = yystate = yytable[yyn];
        *++yyvsp = yylval;
        yychar = (-1);
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;
#if defined(lint) || defined(__GNUC__)
    goto yynewerror;
#endif
yynewerror:
    yyerror("syntax error");
#if defined(lint) || defined(__GNUC__)
    goto yyerrlab;
#endif
yyerrlab:
    ++yynerrs;
yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yyssp, yytable[yyn]);
#endif
                if (yyssp >= yysslim && yygrowstack())
                {
                    goto yyoverflow;
                }
                *++yyssp = yystate = yytable[yyn];
                *++yyvsp = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yyssp);
#endif
                if (yyssp <= yyss) goto yyabort;
                --yyssp;
                --yyvsp;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = (-1);
        goto yyloop;
    }
yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1-yym];
    switch (yyn)
    {
case 4:
#line 24 "grammar.y"
{ printf("  %.8g\n", yyvsp[-1].val); }
break;
case 5:
#line 25 "grammar.y"
{ yyerrok; }
break;
case 6:
#line 28 "grammar.y"
{ 
  if ( isreadonly(yyvsp[-2].sym->name) ) 
    execerr("readonly variable", yyvsp[-2].sym->name);
  yyval.val = yyvsp[-2].sym->u.val = yyvsp[0].val; yyvsp[-2].sym->type = VAR; 
  }
break;
case 8:
#line 36 "grammar.y"
{ if (yyvsp[0].sym->type == UNDEF) 
               execerr("undefined variable", yyvsp[0].sym->name);
             yyval.val = yyvsp[0].sym->u.val; 
            }
break;
case 9:
#line 40 "grammar.y"
{  
              
            }
break;
case 10:
#line 43 "grammar.y"
{ yyval.val = (*(yyvsp[-3].sym->u.ptr))(yyvsp[-1].val); }
break;
case 11:
#line 44 "grammar.y"
{ yyval.val = (*(yyvsp[-2].sym->u.ptr))(); }
break;
case 12:
#line 45 "grammar.y"
{ yyval.val = yyvsp[-2].val + yyvsp[0].val; }
break;
case 13:
#line 46 "grammar.y"
{ yyval.val = yyvsp[-2].val - yyvsp[0].val; }
break;
case 14:
#line 47 "grammar.y"
{ yyval.val = yyvsp[-2].val * yyvsp[0].val; }
break;
case 15:
#line 48 "grammar.y"
{ if (yyvsp[0].val == 0.0) 
                         execerr("division by zero", "");
                       yyval.val = yyvsp[-2].val / yyvsp[0].val; }
break;
case 16:
#line 51 "grammar.y"
{ yyval.val = (int) yyvsp[-2].val % (int) yyvsp[0].val; }
break;
case 17:
#line 52 "grammar.y"
{ yyval.val = dpow(yyvsp[-2].val, yyvsp[0].val); }
break;
case 18:
#line 53 "grammar.y"
{ yyval.val = yyvsp[-1].val; }
break;
case 19:
#line 54 "grammar.y"
{ yyval.val = yyvsp[0].val; }
break;
case 20:
#line 55 "grammar.y"
{ yyval.val = -yyvsp[0].val; }
break;
#line 525 "y.tab.c"
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yyssp = YYFINAL;
        *++yyvsp = yyval;
        if (yychar < 0)
        {
            if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yyssp, yystate);
#endif
    if (yyssp >= yysslim && yygrowstack())
    {
        goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;
yyoverflow:
    yyerror("yacc stack overflow");
yyabort:
    return (1);
yyaccept:
    return (0);
}
