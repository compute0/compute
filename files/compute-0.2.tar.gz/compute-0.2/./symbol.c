#include <stdlib.h>
#include "symbol.h"
#include "y.tab.h"

void execerr(char *, char *);

static symbol *symlist = 0;

symbol *lookup(char *s)
{
  symbol *sp;

  for (sp = symlist; sp; sp = sp->next)
    if ( !strcmp(sp->name, s) ) return sp;
  return 0;
}

void *emalloc(unsigned int n)
{
  void *p; p = malloc(n); 
  if (!p) execerr("out of memory", (char*) 0);
  return p;
}

symbol *install(char *s, int t, double d)
{
  symbol *sp;

  sp = emalloc(sizeof *sp); 
  sp->name = emalloc( strlen(s) + 1 );
  strcpy(sp->name, s); 
  sp->type = t;
  sp->u.val = d;
  sp->next = symlist;
  symlist = sp;
  return sp;  
}

