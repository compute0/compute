#ifndef YYERRCODE
#define YYERRCODE 256
#endif

#define NUMBER 257
#define VAR 258
#define BLTIN 259
#define UNDEF 260
#define UNARYPLUS 261
#define UNARYMINUS 262
typedef union { double val; symbol *sym; } YYSTYPE;
extern YYSTYPE yylval;
