#include <math.h>
#include <errno.h>
#include <time.h>

extern void execerr();

static unsigned long seed;

static unsigned int r(void)
{
  if (!seed) seed = time(0); 

  seed = seed * 1103515245 + 12345;
  return (unsigned int) (seed/65536) % 32768;
}

double errcheck(double d, char *s)
{
  if (errno == EDOM) {
    errno = 0;
    execerr(s, "argument out of domain");
  } else if (errno == ERANGE) {
    errno = 0;
    execerr(s, "result out of range");
  }

  return d;
}

double drand(void)
{
  return (double) r();
}

double dlog(double x)
{
  return errcheck(log(x),"log");
}

double dlog10(double x)
{
  return errcheck(log10(x),"log10");
}

double dexp(double x)
{
  return errcheck(exp(x), "exp");
}

double dsqrt(double x)
{
  return errcheck(sqrt(x), "sqrt");
}

double dpow(double x, double y)
{
  return errcheck(pow(x,y), "exponentiation");
}

double dinteger(double x)
{
  return (double)(long) x;
}
