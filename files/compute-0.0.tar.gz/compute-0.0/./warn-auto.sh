#!/bin/sh
# WARNING: This file was auto-generated.
