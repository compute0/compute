#define NUMBER 257
#define VAR 258
#define BUILTIN 259
#define UNDEF 260
typedef union { symbol *sym; instruction *inst; } YYSTYPE;
extern YYSTYPE yylval;
