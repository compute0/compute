#ifndef BUILTIN_H
#define BUILTIN_H

double errcheck(double d, char *s);
double do_rand(double lim);
double do_log(double x);
double do_log10(double x);
double do_exp(double x);
double do_sqrt(double x);
double do_pow(double x, double y);
double do_int(double x);

#endif
