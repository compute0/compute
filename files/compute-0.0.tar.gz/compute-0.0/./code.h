#ifndef CODE_H
#define CODE_H

extern void initcode();
extern void execute();

extern void eval();
extern void assign();
extern void varpush();
extern void constpush();
extern void print();

extern instruction *code();

#endif
