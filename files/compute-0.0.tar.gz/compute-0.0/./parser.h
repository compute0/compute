#ifndef PARSER_H
#define PARSER_H

int yylex(void); 
void warn(char *, char *); 
void yyerror(char *s); 
int yyparse(); 
void fpecatch(int); 
void execerr(char *, char *);
void init(void); 
int isreadonly(char*);

#endif
