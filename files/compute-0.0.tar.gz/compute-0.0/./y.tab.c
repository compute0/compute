#ifndef lint
static const char yysccsid[] = "@(#)yaccpar	1.9 (Berkeley) 02/21/93";
#endif

#include <stdlib.h>

#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define YYPATCH 20050813

#define YYEMPTY (-1)
#define yyclearin    (yychar = YYEMPTY)
#define yyerrok      (yyerrflag = 0)
#define YYRECOVERING (yyerrflag != 0)

extern int yyparse(void);

static int yygrowstack(void);
#define YYPREFIX "yy"
#line 2 "grammar.y"
#include "symbol.h"
#include "code.h"

#define code2(c1, c2) code(c1); code(c2)
#define code3(c1,c2,c3) code(c1); code(c2); code(c3)
#line 9 "grammar.y"
typedef union { symbol *sym; instruction *inst; } YYSTYPE;
#line 30 "y.tab.c"
#define NUMBER 257
#define VAR 258
#define BUILTIN 259
#define UNDEF 260
#define YYERRCODE 256
short yylhs[] = {                                        -1,
    0,    0,    1,    2,
};
short yylen[] = {                                         2,
    0,    3,    3,    1,
};
short yydefred[] = {                                      1,
    0,    0,    0,    0,    2,    4,    3,
};
short yydgoto[] = {                                       1,
    3,    7,
};
short yysindex[] = {                                      0,
 -258,  -60,  -57, -254,    0,    0,    0,
};
short yyrindex[] = {                                      0,
    0,    0,    0,    0,    0,    0,    0,
};
short yygindex[] = {                                      0,
    0,    0,
};
#define YYTABLESIZE 3
short yytable[] = {                                       2,
    4,    5,    6,
};
short yycheck[] = {                                     258,
   61,   59,  257,
};
#define YYFINAL 1
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 260
#if YYDEBUG
char *yyname[] = {
"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"';'",0,"'='",0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"NUMBER","VAR","BUILTIN",
"UNDEF",
};
char *yyrule[] = {
"$accept : program",
"program :",
"program : program asgn ';'",
"asgn : VAR '=' expr",
"expr : NUMBER",
};
#endif
#if YYDEBUG
#include <stdio.h>
#endif

/* define the initial stack-sizes */
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH  YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 500
#define YYMAXDEPTH  500
#endif
#endif

#define YYINITSTACKSIZE 500

int      yydebug;
int      yynerrs;
int      yyerrflag;
int      yychar;
short   *yyssp;
YYSTYPE *yyvsp;
YYSTYPE  yyval;
YYSTYPE  yylval;

/* variables for the parser stack */
static short   *yyss;
static short   *yysslim;
static YYSTYPE *yyvs;
static int      yystacksize;
#line 27 "grammar.y"

#include <stdio.h>
#include <ctype.h>
#include <signal.h>
#include <setjmp.h>
#include "parser.h"

char *progname; int lineno; jmp_buf begin;


int main(int argc, char *argv[])
{
  progname = argv[0]; 
  setjmp(begin); signal(SIGFPE, fpecatch);

  for ( initcode(); yyparse(); initcode() )
    execute(prog);
  exit(0);
}

int yylex(void)
{
  /* we begin by skipping spaces and tabs. if it's EOF, it's over. if
   * tokens begin with a dot or a number, then we're reading a
   * double. so we feed it back into the stream, and call scanf(); then
   * we install the symbol. */

  int c; /* skip blanks */
  while ( (c = getchar()) == ' ' || c == '\t' || c == '\n') {
    if (c == '\n') ++lineno;
    continue;
  }

  if (c == EOF) return 0;

  if (c == '.' || isdigit(c)) { 
    double d;
    ungetc(c, stdin); 
    scanf("%lf", &d); 
    yylval.sym = install("", NUMBER, d);
    return NUMBER;
  }

  /* if it's a variable or a function call, then read the string byte by
   * byte. notice the allocations first. now, first put the first letter
   * (which we already read) into the buffer, but notice we're using a
   * pointer. now, if we still have more to read, we need to repeat; but
   * if what we read next is not part of the string, then we need to
   * stop. also, if the string is getting too long, we also need to
   * stop; notice that the subtraction gives how many bytes we already
   * used of the buffer, so if that happens to be equal to the maximum
   * capacity of the buffer which is, then quit. and if that happens to
   * be why we bailed out from the while loop, we will notice on the
   * next if. */

  if (isalpha(c)) {
    symbol *s; char sbf[SYMSIZE + 1]; char *p; p = sbf;

    do { *p++ = c; } 
    while( (c=getchar()) != EOF && isalnum(c) && (p - sbf < (SYMSIZE + 1)) );

    if ( (p - sbf) == SYMSIZE + 1) { /* token too long */
      warn("token too long", (char*) 0); longjmp(begin, 0);
    }

    /* we only notice that we're done when we read the next byte which
     * doesn't belong in the string, so we gotta put that byte back in
     * the stream; once we do that, we close the string; and finally we
     * look it up; if the symbol is a built in symbol, we will find it
     * with lookup(); if not, we must install it. if we install it, then
     * it's first appearance; hence its value is still undefined. */
    
    ungetc(c, stdin); *p = '\0';

    if ( (s=lookup(sbf)) == 0 ) 
      s = install(sbf, UNDEF, 0.0);
    
    yylval.sym = s; return s->type == UNDEF ? VAR : s->type;
  }

  return c;
}

void warn(char *s, char *t)
{
  fprintf(stderr, "%s: %s", progname, s); 
  if (t) fprintf(stderr, " %s", t);
  fprintf(stderr, " near line %d\n", lineno);
}

void yyerror(char *s)
{
  warn(s, (char *) 0);
}

void execerr(char *s, char *t)
{
  warn(s, t); longjmp(begin, 0);
}

void fpecatch(int e)
{
  execerr("floating point exception", (char *) 0);
}
#line 226 "y.tab.c"
/* allocate initial stack or double stack size, up to YYMAXDEPTH */
static int yygrowstack(void)
{
    int newsize, i;
    short *newss;
    YYSTYPE *newvs;

    if ((newsize = yystacksize) == 0)
        newsize = YYINITSTACKSIZE;
    else if (newsize >= YYMAXDEPTH)
        return -1;
    else if ((newsize *= 2) > YYMAXDEPTH)
        newsize = YYMAXDEPTH;

    i = yyssp - yyss;
    newss = (yyss != 0)
          ? (short *)realloc(yyss, newsize * sizeof(*newss))
          : (short *)malloc(newsize * sizeof(*newss));
    if (newss == 0)
        return -1;

    yyss  = newss;
    yyssp = newss + i;
    newvs = (yyvs != 0)
          ? (YYSTYPE *)realloc(yyvs, newsize * sizeof(*newvs))
          : (YYSTYPE *)malloc(newsize * sizeof(*newvs));
    if (newvs == 0)
        return -1;

    yyvs = newvs;
    yyvsp = newvs + i;
    yystacksize = newsize;
    yysslim = yyss + newsize - 1;
    return 0;
}

#define YYABORT goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab
int
yyparse(void)
{
    register int yym, yyn, yystate;
#if YYDEBUG
    register const char *yys;

    if ((yys = getenv("YYDEBUG")) != 0)
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = YYEMPTY;

    if (yyss == NULL && yygrowstack()) goto yyoverflow;
    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if ((yyn = yydefred[yystate]) != 0) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yyssp >= yysslim && yygrowstack())
        {
            goto yyoverflow;
        }
        *++yyssp = yystate = yytable[yyn];
        *++yyvsp = yylval;
        yychar = YYEMPTY;
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;

    yyerror("syntax error");

#ifdef lint
    goto yyerrlab;
#endif

yyerrlab:
    ++yynerrs;

yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yyssp, yytable[yyn]);
#endif
                if (yyssp >= yysslim && yygrowstack())
                {
                    goto yyoverflow;
                }
                *++yyssp = yystate = yytable[yyn];
                *++yyvsp = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yyssp);
#endif
                if (yyssp <= yyss) goto yyabort;
                --yyssp;
                --yyvsp;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = YYEMPTY;
        goto yyloop;
    }

yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1-yym];
    switch (yyn)
    {
case 2:
#line 18 "grammar.y"
{ code2(pop, STOP); return 1; }
break;
case 3:
#line 21 "grammar.y"
{ code3(varpush, (instruction) yyvsp[-2].sym, assign); }
break;
case 4:
#line 24 "grammar.y"
{ code2(constpush, (instruction) yyvsp[0].sym); }
break;
#line 416 "y.tab.c"
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yyssp = YYFINAL;
        *++yyvsp = yyval;
        if (yychar < 0)
        {
            if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yyssp, yystate);
#endif
    if (yyssp >= yysslim && yygrowstack())
    {
        goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;

yyoverflow:
    yyerror("yacc stack overflow");

yyabort:
    return (1);

yyaccept:
    return (0);
}
